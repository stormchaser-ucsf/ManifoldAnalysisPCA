# ManifoldAnalysisPCA
 
 (C) Nikhilesh Naraj, 2022

 
 bibtex:
@article{natraj2022compartmentalized,
  title={Compartmentalized dynamics within a common multi-area mesoscale manifold represent a repertoire of human hand movements},
  author={Natraj, Nikhilesh and Silversmith, Daniel B and Chang, Edward F and Ganguly, Karunesh},
  journal={Neuron},
  volume={110},
  number={1},
  pages={154--174},
  year={2022},
  publisher={Elsevier}
}
